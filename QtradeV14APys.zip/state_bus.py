# state_bus.py
from dataclasses import dataclass, asdict, field
from time import time
from typing import Dict, Set, Optional

@dataclass
class Heartbeat:
    seq: int = 0
    ts: float = 0.0
    uptime_s: int = 0
    last_tick_age_s: Optional[int] = None
    last_pos_sync_age_s: Optional[int] = None
    subs: int = 0
    ib_connected: bool = False
    live_mode: bool = False
    dry_run: bool = True
    loop_lag_ms: Optional[int] = None
    symbols: int = 0

@dataclass
class StateBus:
    started_at: float = field(default_factory=time)
    last_tick_at: Optional[float] = None
    last_pos_sync_at: Optional[float] = None
    symbols_subscribed: Set[str] = field(default_factory=set)
    ib_connected: bool = False
    live_mode: bool = False
    dry_run: bool = True
    loop_lag_ms: Optional[int] = None
    pnl_today: float = 0.0
    open_orders: int = 0
    prices: Dict[str, float] = field(default_factory=dict)
    ema8: Dict[str, float] = field(default_factory=dict)
    ema21: Dict[str, float] = field(default_factory=dict)
    heartbeat: Heartbeat = field(default_factory=Heartbeat)

    def mark_tick(self, symbol: str, price: float):
        self.prices[symbol] = price
        self.last_tick_at = time()

    def mark_pos_sync(self):
        self.last_pos_sync_at = time()

    def snapshot(self) -> Dict:
        hb = self.heartbeat
        return {
            "heartbeat": asdict(hb),
            "pnl_today": self.pnl_today,
            "open_orders": self.open_orders,
            "subscriptions": len(self.symbols_subscribed),
            "positions": [],  # dashboard_server fills from TradeManager
            "prices": self.prices,
            "ema8": self.ema8,
            "ema21": self.ema21,
        }

    def update_heartbeat(self, seq: int):
        now = time()
        self.heartbeat = Heartbeat(
            seq=seq,
            ts=now,
            uptime_s=int(now - self.started_at),
            last_tick_age_s=None if self.last_tick_at is None else int(now - self.last_tick_at),
            last_pos_sync_age_s=None if self.last_pos_sync_at is None else int(now - self.last_pos_sync_at),
            subs=len(self.symbols_subscribed),
            ib_connected=self.ib_connected,
            live_mode=self.live_mode and not self.dry_run,
            dry_run=self.dry_run,
            loop_lag_ms=self.loop_lag_ms,
            symbols=len(self.prices),
        )
